import { useState } from "react";
import { Link } from "react-router-dom";
import axios from 'axios';


function Login()
{
    
    const [email,setEmail] = useState()
    const [password,setPassword] = useState()
     const handleSubmit = (e) => {
        e.preventDefault()
        axios.post('http://localhost:3001/login',{email, password})
        .then(result => {console.log(result)
     })
     .catch(err=> console.log(err))
     }
    return (
        <div>
        <h2>login Form</h2>
        <form onSubmit={handleSubmit}>
        <div>
            <label htmlFor="email">Email</label>
            <input
              type="email"
              id="email"
              name="email"
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>

          <div>
            <label htmlFor="password">Password</label>
            <input
              type="password"
              id="password"
              name="password"
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>
          <div>
            <button type="submit">log Up</button>
          </div>
        </form>
      </div>

    )

}

export default Login;